ASEKUNLOWO FURNITURE — BUSINESS PAGE

This is a mobile-friendly one-page website with your supplied WhatsApp, Google Maps, phone and TikTok links.

IMPORTANT:
The page is not yet public on the internet. Before printing a QR code that opens this page, upload/publish index.html using a hosting service and obtain its public URL. Then generate the QR code using that final public URL and test it on another phone.

You can open index.html on a computer to preview it, but that local preview is not a public web address.
